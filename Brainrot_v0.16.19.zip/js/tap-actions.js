/**
 * Interpret the first tap as an X mark and a second quick tap on the same cell
 * as a search. A delayed single action prevents the first tap from causing a
 * misleading X animation during a double tap. Supports deterministic tests.
 */
export function createTapActions({onSingle,onDouble,delayMs=290,schedule=setTimeout,cancelScheduled=clearTimeout}={}){
  if(typeof onSingle!=='function'||typeof onDouble!=='function')throw new TypeError('Tap actions need single and double handlers');
  let pending=null;
  const clear=()=>{if(!pending)return null;const last=pending;cancelScheduled(last.timer);pending=null;return last;};
  return {
    tap(key,payload){
      if(pending && pending.key===key){clear();onDouble(payload);return 'double';}
      if(pending){const previous=clear();onSingle(previous.payload);}
      const next={key,payload,timer:null};
      next.timer=schedule(()=>{if(pending!==next)return;pending=null;onSingle(payload);},delayMs);
      pending=next;
      return 'pending';
    },
    cancel(){clear();},
    flush(){const previous=clear();if(previous)onSingle(previous.payload);},
    get waiting(){return pending!==null;}
  };
}
