# Professor Brainrot Academy v0.16.19

**Complete Android/Codespaces source, mobile-first, offline, original Glorp voice only.**

## What's in this release

- Portrait-first Brain Battle, grade and subject selection, five Logic Lab activities (Lost & Found, Pattern Lab, Shape Lab, Robot Rescue, Slime Sweeper), Parts of Speech Lab, Time and Calendar lessons, original artwork, and parent progress dashboard with PDF export.
- Original Grungle/Glorp speaking clips are retained **byte-for-byte**. The game plays Glorp speech **only for exact recorded dialogue**. Other Glorp lines appear as text with local character sound effects, never robotic speech or a different phrase posing as the same line.
- All educational content, music, art, Glorp speech and character sound effects are installed locally. No network is needed to play the Android app.
- The separate tutorial guide narration is optional, **off by default** in Parent Dashboard. Those tutorial recordings are locally bundled synthesized narration, **not Glorp**. The tutorials remain readable and playable with the narrator off.
- A one-tap **Hear the real Glorp voice** sample is available in Parent Dashboard > Learning & app settings.
- Brain Battle has a compact mobile HUD, short character stage, full-width flexible question and answers, and a non-overlapping How to Play button. Long content scrolls instead of being cut off.
- The Android package ID and existing save-storage keys are unchanged. Android update from a previous debug build requires a compatible signing key.

## GitHub Codespaces: build APK

Upload `Brainrot_Academy_v0.16.19_AUTHENTIC_GLORP_MOBILE_GitHub.zip` into your Codespaces Explorer. If it lands inside `scripts/`, that's fine. Open Terminal and run:

```bash
set -e
ZIP=$(find . -maxdepth 2 -name 'Brainrot_Academy_v0.16.19_AUTHENTIC_GLORP_MOBILE_GitHub.zip' -print -quit)
test -n "$ZIP" || { echo "Upload the ZIP to Codespaces first"; exit 1; }
unzip -oq "$ZIP" -d .
bash scripts/codespaces-build.sh
```

The script selects **Java 21**, installs the Android SDK and dependencies when required, runs the automated tests, and builds the **debug APK**:

`artifacts/Brainrot_Academy_v0.16.19-debug.apk`

Right-click/long-press the APK in **Codespaces > artifacts** to download. A Codespaces terminal build is **not** automatically a GitHub Actions build. The included `.github/workflows/build-android-apk.yml` can build and upload from GitHub Actions after committing and pushing your project to `main`.

## Tests and known limits

- Original Glorp MP3 bytes verified by SHA-256 against preserved pre-restoration source. All ten also pass a media decoder inspection.
- Automated Node suite, offline asset and Android configuration checks pass. Static browser portrait-width screenshots check wrapping and no horizontal overflow. These aren't a substitute for testing an APK on a phone.
- The 12 additional Glorp dialogue scripts have **not** been performed in the original voice. They are not included as synthetic Glorp dialogue and do not play substitute clips.
- This archive is the source project, **not** a prebuilt APK. Run Codespaces to compile and install it, then test it in airplane mode.

For additional technical context see `AUTHENTIC_AUDIO_MOBILE_QA_v0.16.19.md`, `MOBILE_FIRST_RELEASE_NOTES_v0.16.18.md`, and `GITHUB_APK_BUILD.md`. Older release notes are historical and may describe removed experimental voice tracks.
