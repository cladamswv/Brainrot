/** Clean only the known disposable v0.16.15/v0.16.16 robotic Glorp recordings.
 * Safe to run on an existing Codespace or fresh v0.16.17 tree. Original MP3s
 * under assets/audio/voice/*.mp3 are never modified.
 */
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
for(const [folder,prefix,count] of [
  ['intro-reconstruction','glorp-intro',11],
  ['offline-reconstruction','glorp-line',12]
]){
 const dir=path.join(root,'assets','audio','voice',folder);
 if(!fs.existsSync(dir))continue;
 for(let n=1;n<=count;n++){
  const name=`${prefix}-${String(n).padStart(2,'0')}.mp3`;
  fs.rmSync(path.join(dir,name),{force:true});
 }
 if(fs.readdirSync(dir).length===0)fs.rmdirSync(dir);
}
