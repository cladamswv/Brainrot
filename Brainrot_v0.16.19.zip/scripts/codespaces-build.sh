#!/usr/bin/env bash
# One-command Android debug APK build for Linux GitHub Codespaces.
set -euo pipefail
cd "$(dirname "$0")/.."

# Use Java 21 even if the base Codespace defaults to unsupported Java 25.
if [ -x "$HOME/.local/brainrot-jdk21/bin/java" ]; then
  export JAVA_HOME="$HOME/.local/brainrot-jdk21"
elif command -v java >/dev/null 2>&1 && java -version 2>&1 | head -n1 | grep -Eq 'version "21\.|openjdk 21\.'; then
  export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")"
else
  echo 'Java 21 not found; installing a private copy into ~/.local/brainrot-jdk21 ...'
  command -v curl >/dev/null || { echo 'curl is required'; exit 1; }
  mkdir -p "$HOME/.local/brainrot-jdk21"
  tmpfile="$(mktemp /tmp/brainrot-jdk21.XXXXXX.tar.gz)"
  trap 'rm -f "$tmpfile"' EXIT
  curl --fail --location --retry 3 --retry-delay 3 \
    'https://api.adoptium.net/v3/binary/latest/21/ga/linux/x64/jdk/hotspot/normal/eclipse' \
    --output "$tmpfile"
  tar -xzf "$tmpfile" -C "$HOME/.local/brainrot-jdk21" --strip-components=1
  export JAVA_HOME="$HOME/.local/brainrot-jdk21"
fi
export PATH="$JAVA_HOME/bin:$PATH"

echo 'Using Java:'
java -version

export ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/android-sdk}}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"

# Codespaces rebuilds may have their SDK reset; install it if incomplete.
if [ ! -f "$ANDROID_HOME/platforms/android-36/android.jar" ] || [ ! -x "$ANDROID_HOME/build-tools/36.0.0/aapt2" ]; then
  echo 'Setting up Android SDK 36...'
  bash scripts/setup-codespaces-android.sh
fi

echo 'Installing pinned JavaScript dependencies...'
npm ci

echo 'Running all tests...'
npm test

echo 'Building the debug APK...'
npm run android:build

echo '-------------------------------------------------------------------------'
echo 'SUCCESS. Download this file from the Codespaces Explorer:'
ls -lh artifacts/Brainrot_Academy_v0.16.19-debug.apk
