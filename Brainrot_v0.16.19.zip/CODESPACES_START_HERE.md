# Brainrot Academy v0.16.19 - mobile-first, offline Android build

This is the **full source package**, not a small patch. It builds on v0.16.17, retains the authentic original Glorp voice clips and offline lessons, and replaces the crowded desktop-in-a-phone battle arrangement with portrait-first responsive layouts. Existing save storage and Android app ID are unchanged. Android versionCode is 1619.

## On your Android phone in GitHub Codespaces

1. Download `Brainrot_Academy_v0.16.19_AUTHENTIC_GLORP_MOBILE_GitHub.zip` from ChatGPT.
2. In VS Code Codespaces Explorer upload the ZIP to **Brain** (the repository root). If your phone puts it inside `scripts`, that's also supported.
3. Open **Terminal > New Terminal**. Paste this complete block:

```bash
set -e
ZIP=$(find . -maxdepth 2 -name 'Brainrot_Academy_v0.16.19_AUTHENTIC_GLORP_MOBILE_GitHub.zip' -print -quit)
test -n "$ZIP" || { echo 'Upload the v0.16.19 ZIP first'; exit 1; }
unzip -oq "$ZIP" -d .
bash scripts/codespaces-build.sh
```

4. Expand **artifacts** in Codespaces Explorer and download `Brainrot_Academy_v0.16.19-debug.apk`. The Codespaces build does **not** automatically appear under GitHub Actions.

The script uses **Java 21**, installs dependencies, runs all tests, prepares Android SDK 36, and builds the APK. Build tools require internet; **installed gameplay, tutorials, questions, art and bundled audio do not**.

## If you want GitHub Actions artifacts

After extracting the source, commit and push the files to `main` (Git ignores ZIPs, Android temp output, `node_modules`, and `www`). The included `.github/workflows/build-android-apk.yml` uploads the debug APK as an Actions artifact. Its debug signing key can differ from a Codespaces build. Back up saved progress before uninstalling an existing build if Android refuses an in-place update.

## Read the checks

See `AUTHENTIC_AUDIO_MOBILE_QA_v0.16.19.md` and `MOBILE_FIRST_RELEASE_NOTES_v0.16.18.md` for the mobile layout changes and honest verification limitations.
