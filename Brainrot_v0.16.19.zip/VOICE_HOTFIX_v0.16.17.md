# Glorp original voice restoration v0.16.17

- Root cause: v0.16.16 played temporary robotic synthetic voice files for 11 openings and 12 reactions.
- Restored the original ten voiced lines from authentic v0.16.9 assets. **No original MP3s were changed.**
- Opening draws six actual Glorp original sayings, displaying the exact words on screen.
- Main Brain Battle correct/wrong/angry/furious/meltdown reaction banks use actual phrases present in the original voice assets.
- Archive-only dialogue variants from later versions have semantic fallback to original clips, rather than falsely claiming the original spoken scripts were recorded. These are not word-for-word matches and should be newly recorded in Grungle voice later.
- Removed all 23 temporary synthetic character audio files.
- Kept tutorial/narrator audio as a separate voice, plus original audio, music, questions, tutorials, and saved-game keys.
- Offline cache includes the actual bundled files. No internet is required in the installed game.
- v0.16.17 is not a complete restoration of unrecorded newer dialogue.

To update inside the existing Codespace, unzip the small patch over the project, run `npm test` and then `npm run android:build` with Java 21. Since both builds use the same app ID, an Android update *may* preserve game progress when signed with the same key. Do not uninstall the old app until you've backed up your progress.

A cleanup script automatically removes only the known 23 robotic audio files when this update is installed over v0.16.16. Original character recordings are never touched.
