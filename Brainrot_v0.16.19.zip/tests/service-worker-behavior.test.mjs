import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../sw.js',import.meta.url),'utf8');
function worker(){
  const handlers={},calls=[];
  const cached=new Map([
    ['https://academy.test/index.html',new Response('offline page',{headers:{'Content-Type':'text/html'}})],
    ['https://academy.test/assets/music/battle.mp3',new Response('0123456789',{headers:{'Content-Type':'audio/mpeg'}})]
  ]);
  const cache={match:async request=>{
    const key=typeof request==='string'?new URL(request,'https://academy.test/').href:request.url;
    return cached.get(key);
  },put:async()=>{throw new Error('Offline-only cache attempted network write');}};
  const caches={open:async()=>cache};
  const self={location:{origin:'https://academy.test'},registration:{scope:'https://academy.test/'},addEventListener:(name,handler)=>handlers[name]=handler};
  const fetch=async()=>{calls.push('network');throw new Error('Unexpected network use');};
  vm.runInNewContext(source,{self,caches,fetch,URL,Response,Headers});
  return {handlers,calls};
}
function fetchEvent(url,mode='cors',headers={}){
  return {request:{url,mode,headers:new Headers(headers),method:'GET'},response:null,respondWith(promise){this.response=promise;}};
}
test('offline navigation, images, and music never trigger a network request',async()=>{
  const {handlers,calls}=worker();
  const page=fetchEvent('https://academy.test/lesson','navigate');
  handlers.fetch(page);
  assert.equal(await (await page.response).text(),'offline page');
  const music=fetchEvent('https://academy.test/assets/music/battle.mp3');
  handlers.fetch(music);
  assert.equal(await (await music.response).text(),'0123456789');
  const missing=fetchEvent('https://academy.test/assets/sfx/missing.mp3');
  handlers.fetch(missing);
  assert.equal((await missing.response).status,404);
  assert.deepEqual(calls,[]);
});
test('cached audio supports seeking with HTTP 206 range responses',async()=>{
  const {handlers,calls}=worker();
  const music=fetchEvent('https://academy.test/assets/music/battle.mp3','cors',{Range:'bytes=2-5'});
  handlers.fetch(music);
  const answer=await music.response;
  assert.equal(answer.status,206);
  assert.equal(answer.headers.get('Content-Range'),'bytes 2-5/10');
  assert.equal(await answer.text(),'2345');
  assert.deepEqual(calls,[]);
});
test('service worker ignores requests to unrelated origins',()=>{
  const {handlers}=worker();
  const external=fetchEvent('https://another.test/picture.png');
  handlers.fetch(external);
  assert.equal(external.response,null);
});
