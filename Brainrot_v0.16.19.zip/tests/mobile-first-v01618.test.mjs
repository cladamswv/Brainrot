import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=path=>fs.readFileSync(new URL('../'+path,import.meta.url),'utf8');
const css=read('mobile-first.css');

test('mobile-first styles load after the legacy theme without removing any game screen',()=>{
 const html=read('index.html');
 assert.ok(html.indexOf('href="styles.css"')<html.indexOf('href="mobile-first.css"'));
 for(const id of ['homeScreen','battleScreen','activityScreen','gradeScreen','logicHubScreen','robotLabScreen','shapeLabScreen','slimeLabScreen','patternLabScreen','partsSpeechScreen','parentScreen']){
  assert.ok(html.includes(`id="${id}"`),`${id} missing`);
 }
});

test('phone viewport is true size and does not demand a desktop minimum height',()=>{
 assert.match(read('index.html'),/width=device-width,initial-scale=1,viewport-fit=cover/);
 assert.match(css,/\.app-shell\s*\{[^}]*height:\s*100dvh\s*!important/);
 assert.match(css,/min-height:\s*0\s*!important/);
 assert.match(css,/-webkit-text-size-adjust:\s*100%/);
});

test('mobile battle is a single reading column with compact character and HUD',()=>{
 assert.match(css,/\.battle-main,[\s\S]*?display:flex\s*!important/);
 assert.match(css,/flex-direction:column\s*!important/);
 assert.match(css,/grid-template-columns:unset\s*!important/);
 assert.match(css,/\.battle-main\s*>\s*\.glorp-stage/);
 assert.match(css,/\.battle-top\s*\{[^}]*display:\s*grid\s*!important/);
 assert.match(css,/\.combat-hud:not\(\.hidden\)/);
});

test('question and answers wrap long text instead of clipping it',()=>{
 assert.match(css,/\.quiz-panel \.question:not\(\.professor-hosted-question\)/);
 assert.match(css,/height:auto\s*!important/);
 assert.match(css,/max-height:none\s*!important/);
 assert.match(css,/overflow:visible\s*!important/);
 assert.match(css,/overflow-wrap:anywhere/);
 assert.match(css,/\.quiz-panel \.answer-grid \.answer/);
 assert.match(css,/text-align:left\s*!important/);
 assert.match(css,/grid-template-columns:minmax\(0,1fr\)\s*!important/);
});

test('how to play stays in the document flow, never over option D',()=>{
 assert.match(css,/#battleScreen\s*>\s*\.academy-help-pill/);
 assert.match(css,/\.academy-help-pill,[\s\S]*?position:\s*static\s*!important/);
 assert.match(css,/\.quiz-panel \.answer-continue\s*\{[^}]*position:static\s*!important/);
});

test('logic and touch-game boards are bounded to the phone viewport',()=>{
 for(const name of ['.logic-game-grid','.shape-board','.robot-board','.slime-board','.pattern-answer-grid']){
  assert.ok(css.includes(name),`no responsive sizing for ${name}`);
 }
 assert.match(css,/\.app-dock\s*\{[^}]*env\(safe-area-inset-bottom\)/);
});

test('mobile styles ship both into Android WebView and offline web cache',()=>{
 assert.ok(read('scripts/prepare-web.mjs').includes("'mobile-first.css'"));
 assert.ok(read('scripts/generate-offline-cache.mjs').includes("'mobile-first.css'"));
 assert.ok(read('sw.js').includes("'./mobile-first.css'"));
 assert.equal(read('www/mobile-first.css'),css);
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'0.16.19');
 assert.match(read('scripts/configure-android.mjs'),/versionCode 1619/);
});
