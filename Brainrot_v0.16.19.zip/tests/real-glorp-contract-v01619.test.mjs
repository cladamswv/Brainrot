import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {getCharacterVoiceSource,LEGACY_GLORP_FILES,GLORP_UNRECORDED_SCRIPTS} from '../js/voice-registry.js';

// SHA-256 from the preserved pre-reconstruction source archive. These hashes
// catch accidental replacement of the real character performances by TTS.
const originalHashes = {
  "game-cheating.mp3": "c0a9279a236838f3d2b69415a9a75d830225e37abc9c84385e8a8025963348f5",
  "glorp-wins.mp3": "a97a61c1af347bbee24334bb41441300e51b7246b3fdd2c55ce4e60447560917",
  "grandpas-wifi.mp3": "e90781620fb45094166eaee29dc0a5dd4ca0b3be68a71990817827d80aedbb2c",
  "hotdog.mp3": "5346b4f475d72a8966612bba553804eaa10d9c152760f6d3e9aecf8743f9006a",
  "math-broken.mp3": "e45ff5ca701f2ea59f7ab382eb2fac614842068872ebcdb40d511db7955cb292",
  "potato.mp3": "631230c0cb5a210847508aa11f146510410183040ed7f0ab103b48eeb536da0f",
  "question-rigged.mp3": "94270286b504e9a21b3d191b2d76a77b077baae90425805fdd6ad21ef34e24ad",
  "stop-knowing-math.mp3": "13c5b0f05970afff4261c371c49298bcd10faaa3eafbbbe7a924b4a887cbc4e1",
  "watch-videos.mp3": "909013c2e9667008ae172f5d18d658b06617c9bb18b64d6a475659afbb177e33",
  "what-no.mp3": "8a469d82f7fa28e9ca044e46b99150e6134dbb66cd5c09479a7f32929ea02630"
};
test('the 10 actual original Glorp voice recordings are unchanged',()=>{
 assert.equal(Object.keys(originalHashes).length,10);
 for(const [filename,hash] of Object.entries(originalHashes)){
  const p=new URL('../assets/audio/voice/'+filename,import.meta.url);
  const actual=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
  assert.equal(actual,hash,filename+' differs from original');
 }
});
test('only exact dialogue lines trigger spoken Glorp performances',()=>{
 for(const [line,file] of Object.entries(LEGACY_GLORP_FILES)){
  const source=getCharacterVoiceSource('glorp',line);
  assert.ok(source && source.authentic && !source.approximate,line);
  assert.equal(source.file,file);
 }
 for(const line of GLORP_UNRECORDED_SCRIPTS){
  assert.equal(getCharacterVoiceSource('glorp',line),null,line);
 }
});
test('Glorp real recordings and optional tutorial narrator have separate switches',()=>{
 const app=fs.readFileSync(new URL('../js/app.js',import.meta.url),'utf8');
 const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
 assert.match(html,/id="voiceToggle"/);
 assert.match(html,/id="tutorialNarrationToggle"/);
 assert.match(html,/id="glorpVoicePreviewBtn"/);
 assert.match(app,/tutorialNarration:false/);
 assert.match(app,/getVoiceEnabled:\(\)=>!!prefs.tutorialNarration/);
 assert.match(app,/if\(!prefs.tutorialNarration\)return/);
 assert.doesNotMatch(app,/speechSynthesis|SpeechSynthesisUtterance/);
});
