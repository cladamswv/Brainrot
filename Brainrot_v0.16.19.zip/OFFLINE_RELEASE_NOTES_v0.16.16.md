# Brainrot Academy v0.16.16: Strict Offline Edition

This release is based on the real v0.16.15 rebuilt source, itself restored from the user's authentic v0.16.9 source. It retains the existing Android application ID (`com.brainrotacademy.app`) and does not replace the game with a demo.

## Offline hardening
- Eliminated all 12 leftover remote audio source URLs. They now map directly to the local provisional Glorp voice files.
- Removed code for remote voice fetch, remote playback, and online-only voice fallback.
- Auto-generates a complete offline cache from all runtime files, including every local audio file and every SVG/game image.
- Changed installed web-app navigation and media to cache-only. Navigations that don't match a stored page use the cached game entry page; missing media responds 404 rather than contacting a server.
- Added offline audio byte-range support for seeking.
- Added an automated offline contract that asserts there are no remote runtime URLs or networking calls, all voice/narration/media are included, and `www/` matches the source.
- Updated the version to v0.16.16, including the Android debug APK and GitHub Actions artifact name.

## What works entirely offline
- All originally included games, game rules, tutorials, grade-sensitive lesson practice, local question bank, progress reports and export, original effects/music/art.
- The 11 locally synthesized Glorp intro alternatives, 12 synthetic reaction lines, 50 tutorial narrations, and all original bundled voice clips.
- Offline storage of progress and preferences through WebView localStorage; no online login is required.

## Important caveats
- The 11 reconstructed Glorp intros and 12 reconstructed reaction recordings remain provisional; they are not the exact approved Grungle voice performances. Those original newer recordings were not in the uploaded original source archive.
- Professor Brainrot's conversational speech bubbles deliberately remain text-only (original product design). This is not an online feature.
- First-time GitHub Codespaces creation/build downloads Node/Android developer tools, but the INSTALLED Android app needs no Wi-Fi, cellular network, or server. A web/PWA install requires the initial online download of every file; once installed it can run offline.
- A full Android APK compilation and an airplane-mode phone smoke test are still needed in Codespaces / on device. Node tests alone do not prove runtime behavior on every phone.
- App updates preserve local progress only with compatible signing and installation over the existing app. Uninstalling can delete local data.

## Build
Unzip source into a fresh GitHub repository/Codespace, then run:

```bash
set -e
npm ci
npm test
npm run android:build
```

Debug APK: `artifacts/Brainrot_Academy_v0.16.16-debug.apk`.

## Airplane-mode smoke test on Android
1. Install the APK, open the game once, choose a grade, and play a question.
2. Turn on Airplane mode. Fully close the app and reopen it with Wi-Fi and cellular data both off.
3. Run Brain Battle, Lost & Found, Slime Sweeper, Robot Rescue, and Parts of Speech.
4. Open each How to Play tutorial; tap Listen on Time, Calendar, and Grammar lessons.
5. Hear the menu music, Glorp's local intro, sound effects and reaction clips. Verify that all images load.
6. Complete a question, fully close/reopen again offline, and verify saved progress and the parent dashboard/PDF export.
