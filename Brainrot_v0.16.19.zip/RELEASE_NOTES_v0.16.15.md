# Professor Brainrot Academy v0.16.15

## Additions
- Step-by-step tutorials for every mini-game and the two game-selection screens.
- First-use explanations plus replayable HOW TO PLAY button. Pause-aware tutorial overlay, keyboard focus management and Android back closing.
- Three educational warmups: clocks/elapsed time, weekdays/months/calendar dates, grammar. Each has lesson slides, examples, a selectable quiz, correct-answer explanations and grade-sensitive questions.
- 50 pre-bundled MP3 narrations for the lessons/tutorials. Tap LISTEN to hear the current card. All narration stored locally.
- 11 new Glorp opening variations in locally synthesized audio.
- 12 re-created *line texts* spoken in offline synthetic voices, NOT authentic Grungle. They replace fragile remote audio references while keeping original 10+ legacy Glorp clips as-is.
- Original Parts of Speech Lab with 8 lessons is preserved, not rewritten.

## Important limitations
- The original paid/proprietary Grungle performance clips from 0.16.13–0.16.14 were not in the supplied v0.16.9 ZIP. New local voice clips are temporary speech placeholders and sound different.
- A new genuine Grungle intro recording was generated in a connected account during this session, but cannot be embedded in the archive from its URL in this environment.
- Tests are automated source/logic tests. Actual Android APK compilation and phone audio playback must be validated in GitHub Codespaces and on-device.

## Codespaces build
```bash
set -e
unzip -oq Brainrot_Academy_v0.16.15_Offline_Tutorials_Codespaces.zip -d .
npm ci
npm test
bash scripts/setup-codespaces-android.sh
npm run android:build
```

Debug APK: `artifacts/Brainrot_Academy_v0.16.15-debug.apk`. Existing installed app can preserve progress if installed with compatible signing; back up save data before uninstalling an older copy.
